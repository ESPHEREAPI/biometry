<?php

namespace Application\Manager;


class EmployeManager extends CommonManager
{
    public function getListeEmploye($statut=null, $profil=null, $genre=null, $supprime=null, $nroPage=1, $nbreMax=null, $pagination=false, $categorie=null, $prestataire=null)
    {
		$dqlNbreElt = "";
		
    	$dql = "FROM Entity\Employe emp
    			JOIN emp.utilisateur u
                JOIN emp.prestataire presta
    			WHERE 1 = 1";
    	
    	if(!empty($statut))
    		$dql .= " AND u.statut = '".$statut."'";
    	if(!empty($genre))
    		$dql .= " AND u.genre = '".$genre."'";
    	if(!empty($supprime))
    		$dql .= " AND u.supprime = '".$supprime."'";
    	if(!empty($profil))
    		$dql .= " AND emp.profil = '".$profil."'";
    	
		if(!empty($categorie))
		    $dql .= " AND presta.categorie = '".$categorie."'";
		
	    if(!empty($prestataire))
	        $dql .= " AND presta.id = '".$prestataire."'";
    	
    	$dql .= " ORDER BY u.nom ASC, u.prenom";
    	
    	
    	
    	
    	if($pagination)
    		$dqlNbreElt = "SELECT COUNT(emp.id) ".$dql;
    	 
    	$dql = "SELECT emp ".$dql;
    	
    	return $this->getPaginator($dql, $nroPage, $nbreMax, $dqlNbreElt, $pagination);
    }
}
