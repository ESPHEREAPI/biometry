<?php

namespace Entity;

use Doctrine\ORM\Mapping as ORM;
use Custom\Model\Entity;

/**
 * AyantDroit
 *
 * @ORM\Table(name="dbx45ty_ayant_droit", indexes={@ORM\Index(name="code_adherent", columns={"code_adherent"})})
 * @ORM\Entity
 */
class AyantDroit extends Entity
{
    /**
     * @var string
     *
     * @ORM\Column(name="code_ayant_droit", type="string", length=255, nullable=false)
     * @ORM\Id
     */
    protected $codeAyantDroit;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255, nullable=true)
     */
    protected $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="sexe", type="string", length=5, nullable=true)
     */
    protected $sexe;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="naissance", type="date", nullable=true)
     */
    protected $naissance;

    /**
     * @var string
     *
     * @ORM\Column(name="police", type="string", length=100, nullable=true)
     */
    protected $police;

    /**
     * @var \Entity\Adherent
     *
     * @ORM\ManyToOne(targetEntity="Entity\Adherent")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="code_adherent", referencedColumnName="code_adherent")
     * })
     */
    protected $codeAdherent;



    /**
     * Get codeAyantDroit
     *
     * @return string
     */
    public function getCodeAyantDroit()
    {
        return $this->codeAyantDroit;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return AyantDroit
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set sexe
     *
     * @param string $sexe
     *
     * @return AyantDroit
     */
    public function setSexe($sexe)
    {
        $this->sexe = $sexe;

        return $this;
    }

    /**
     * Get sexe
     *
     * @return string
     */
    public function getSexe()
    {
        return $this->sexe;
    }

    /**
     * Set naissance
     *
     * @param \DateTime $naissance
     *
     * @return AyantDroit
     */
    public function setNaissance($naissance)
    {
        $this->naissance = $naissance;

        return $this;
    }

    /**
     * Get naissance
     *
     * @return \DateTime
     */
    public function getNaissance()
    {
        return $this->naissance;
    }

    /**
     * Set police
     *
     * @param string $police
     *
     * @return AyantDroit
     */
    public function setPolice($police)
    {
        $this->police = $police;

        return $this;
    }

    /**
     * Get police
     *
     * @return string
     */
    public function getPolice()
    {
        return $this->police;
    }

    /**
     * Set codeAdherent
     *
     * @param \Entity\Adherent $codeAdherent
     *
     * @return AyantDroit
     */
    public function setCodeAdherent(\Entity\Adherent $codeAdherent = null)
    {
        $this->codeAdherent = $codeAdherent;

        return $this;
    }

    /**
     * Get codeAdherent
     *
     * @return \Entity\Adherent
     */
    public function getCodeAdherent()
    {
        return $this->codeAdherent;
    }
}
