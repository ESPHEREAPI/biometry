<?php

namespace Entity;

use Doctrine\ORM\Mapping as ORM;
use Custom\Model\Entity;

/**
 * LignePrestation
 *
 * @ORM\Table(name="dbx45ty_ligne_prestation", indexes={@ORM\Index(name="prestation_id", columns={"prestation_id"}), @ORM\Index(name="prestataire_id", columns={"prestataire_id"}), @ORM\Index(name="employe_valide_rejete_id", columns={"employe_valide_rejete_id"}), @ORM\Index(name="type_examen", columns={"type_examen"})})
 * @ORM\Entity
 */
class LignePrestation extends Entity
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var float
     *
     * @ORM\Column(name="taux", type="float", precision=10, scale=0, nullable=true)
     */
    protected $taux;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=255, nullable=false)
     */
    protected $nom;

    /**
     * @var float
     *
     * @ORM\Column(name="valeur", type="float", precision=10, scale=0, nullable=true)
     */
    protected $valeur;

    /**
     * @var float
     *
     * @ORM\Column(name="nbre", type="float", precision=10, scale=0, nullable=true)
     */
    protected $nbre;

    /**
     * @var float
     *
     * @ORM\Column(name="acte_prelevement", type="float", precision=10, scale=0, nullable=false)
     */
    protected $actePrelevement = '0';

    /**
     * @var float
     *
     * @ORM\Column(name="valeur_modif", type="float", precision=10, scale=0, nullable=true)
     */
    protected $valeurModif;

    /**
     * @var float
     *
     * @ORM\Column(name="nbre_modif", type="float", precision=10, scale=0, nullable=true)
     */
    protected $nbreModif;

    /**
     * @var float
     *
     * @ORM\Column(name="acte_prelevement_modif", type="float", precision=10, scale=0, nullable=false)
     */
    protected $actePrelevementModif = '0';

    /**
     * @var string
     *
     * @ORM\Column(name="posologie", type="string", length=255, nullable=true)
     */
    protected $posologie;

    /**
     * @var string
     *
     * @ORM\Column(name="observations", type="string", length=255, nullable=true)
     */
    protected $observations;

    /**
     * @var string
     *
     * @ORM\Column(name="observations_acte_prelevement", type="string", length=255, nullable=true)
     */
    protected $observationsActePrelevement;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="datetime", nullable=false)
     */
    protected $date;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date_encaisse", type="datetime", nullable=true)
     */
    protected $dateEncaisse;

    /**
     * @var string
     *
     * @ORM\Column(name="etat", type="string", nullable=false)
     */
    protected $etat = 'enregistre';

    /**
     * @var string
     *
     * @ORM\Column(name="supprime", type="string", nullable=false)
     */
    protected $supprime = '-1';

    /**
     * @var \Entity\Prestation
     *
     * @ORM\ManyToOne(targetEntity="Entity\Prestation")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="prestation_id", referencedColumnName="id")
     * })
     */
    protected $prestation;

    /**
     * @var \Entity\Prestataire
     *
     * @ORM\ManyToOne(targetEntity="Entity\Prestataire")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="prestataire_id", referencedColumnName="id")
     * })
     */
    protected $prestataire;

    /**
     * @var \Entity\Employe
     *
     * @ORM\ManyToOne(targetEntity="Entity\Employe")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="employe_valide_rejete_id", referencedColumnName="id")
     * })
     */
    protected $employeValideRejete;

    /**
     * @var \Entity\TypePrestation
     *
     * @ORM\ManyToOne(targetEntity="Entity\TypePrestation")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="type_examen", referencedColumnName="id")
     * })
     */
    protected $typeExamen;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set taux
     *
     * @param float $taux
     *
     * @return LignePrestation
     */
    public function setTaux($taux)
    {
        $this->taux = $taux;

        return $this;
    }

    /**
     * Get taux
     *
     * @return float
     */
    public function getTaux()
    {
        return $this->taux;
    }

    /**
     * Set nom
     *
     * @param string $nom
     *
     * @return LignePrestation
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set valeur
     *
     * @param float $valeur
     *
     * @return LignePrestation
     */
    public function setValeur($valeur)
    {
        $this->valeur = $valeur;

        return $this;
    }

    /**
     * Get valeur
     *
     * @return float
     */
    public function getValeur()
    {
        return $this->valeur;
    }

    /**
     * Set nbre
     *
     * @param float $nbre
     *
     * @return LignePrestation
     */
    public function setNbre($nbre)
    {
        $this->nbre = $nbre;

        return $this;
    }

    /**
     * Get nbre
     *
     * @return float
     */
    public function getNbre()
    {
        return $this->nbre;
    }

    /**
     * Set actePrelevement
     *
     * @param float $actePrelevement
     *
     * @return LignePrestation
     */
    public function setActePrelevement($actePrelevement)
    {
        $this->actePrelevement = $actePrelevement;

        return $this;
    }

    /**
     * Get actePrelevement
     *
     * @return float
     */
    public function getActePrelevement()
    {
        return $this->actePrelevement;
    }

    /**
     * Set valeurModif
     *
     * @param float $valeurModif
     *
     * @return LignePrestation
     */
    public function setValeurModif($valeurModif)
    {
        $this->valeurModif = $valeurModif;

        return $this;
    }

    /**
     * Get valeurModif
     *
     * @return float
     */
    public function getValeurModif()
    {
        return $this->valeurModif;
    }

    /**
     * Set nbreModif
     *
     * @param float $nbreModif
     *
     * @return LignePrestation
     */
    public function setNbreModif($nbreModif)
    {
        $this->nbreModif = $nbreModif;

        return $this;
    }

    /**
     * Get nbreModif
     *
     * @return float
     */
    public function getNbreModif()
    {
        return $this->nbreModif;
    }

    /**
     * Set actePrelevementModif
     *
     * @param float $actePrelevementModif
     *
     * @return LignePrestation
     */
    public function setActePrelevementModif($actePrelevementModif)
    {
        $this->actePrelevementModif = $actePrelevementModif;

        return $this;
    }

    /**
     * Get actePrelevementModif
     *
     * @return float
     */
    public function getActePrelevementModif()
    {
        return $this->actePrelevementModif;
    }

    /**
     * Set posologie
     *
     * @param string $posologie
     *
     * @return LignePrestation
     */
    public function setPosologie($posologie)
    {
        $this->posologie = $posologie;

        return $this;
    }

    /**
     * Get posologie
     *
     * @return string
     */
    public function getPosologie()
    {
        return $this->posologie;
    }

    /**
     * Set observations
     *
     * @param string $observations
     *
     * @return LignePrestation
     */
    public function setObservations($observations)
    {
        $this->observations = $observations;

        return $this;
    }

    /**
     * Get observations
     *
     * @return string
     */
    public function getObservations()
    {
        return $this->observations;
    }

    /**
     * Set observationsActePrelevement
     *
     * @param string $observationsActePrelevement
     *
     * @return LignePrestation
     */
    public function setObservationsActePrelevement($observationsActePrelevement)
    {
        $this->observationsActePrelevement = $observationsActePrelevement;

        return $this;
    }

    /**
     * Get observationsActePrelevement
     *
     * @return string
     */
    public function getObservationsActePrelevement()
    {
        return $this->observationsActePrelevement;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     *
     * @return LignePrestation
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set dateEncaisse
     *
     * @param \DateTime $dateEncaisse
     *
     * @return LignePrestation
     */
    public function setDateEncaisse($dateEncaisse)
    {
        $this->dateEncaisse = $dateEncaisse;

        return $this;
    }

    /**
     * Get dateEncaisse
     *
     * @return \DateTime
     */
    public function getDateEncaisse()
    {
        return $this->dateEncaisse;
    }

    /**
     * Set etat
     *
     * @param string $etat
     *
     * @return LignePrestation
     */
    public function setEtat($etat)
    {
        $this->etat = $etat;

        return $this;
    }

    /**
     * Get etat
     *
     * @return string
     */
    public function getEtat()
    {
        return $this->etat;
    }

    /**
     * Set supprime
     *
     * @param string $supprime
     *
     * @return LignePrestation
     */
    public function setSupprime($supprime)
    {
        $this->supprime = $supprime;

        return $this;
    }

    /**
     * Get supprime
     *
     * @return string
     */
    public function getSupprime()
    {
        return $this->supprime;
    }

    /**
     * Set prestation
     *
     * @param \Entity\Prestation $prestation
     *
     * @return LignePrestation
     */
    public function setPrestation(\Entity\Prestation $prestation = null)
    {
        $this->prestation = $prestation;

        return $this;
    }

    /**
     * Get prestation
     *
     * @return \Entity\Prestation
     */
    public function getPrestation()
    {
        return $this->prestation;
    }

    /**
     * Set prestataire
     *
     * @param \Entity\Prestataire $prestataire
     *
     * @return LignePrestation
     */
    public function setPrestataire(\Entity\Prestataire $prestataire = null)
    {
        $this->prestataire = $prestataire;

        return $this;
    }

    /**
     * Get prestataire
     *
     * @return \Entity\Prestataire
     */
    public function getPrestataire()
    {
        return $this->prestataire;
    }

    /**
     * Set employeValideRejete
     *
     * @param \Entity\Employe $employeValideRejete
     *
     * @return LignePrestation
     */
    public function setEmployeValideRejete(\Entity\Employe $employeValideRejete = null)
    {
        $this->employeValideRejete = $employeValideRejete;

        return $this;
    }

    /**
     * Get employeValideRejete
     *
     * @return \Entity\Employe
     */
    public function getEmployeValideRejete()
    {
        return $this->employeValideRejete;
    }

    /**
     * Set typeExamen
     *
     * @param \Entity\TypePrestation $typeExamen
     *
     * @return LignePrestation
     */
    public function setTypeExamen(\Entity\TypePrestation $typeExamen = null)
    {
        $this->typeExamen = $typeExamen;

        return $this;
    }

    /**
     * Get typeExamen
     *
     * @return \Entity\TypePrestation
     */
    public function getTypeExamen()
    {
        return $this->typeExamen;
    }
}
