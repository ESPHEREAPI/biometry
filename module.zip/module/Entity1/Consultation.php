<?php

namespace Entity;

use Doctrine\ORM\Mapping as ORM;
use Custom\Model\Entity;

/**
 * Consultation
 *
 * @ORM\Table(name="dbx45ty_consultation", uniqueConstraints={@ORM\UniqueConstraint(name="visite_id", columns={"visite_id"})}, indexes={@ORM\Index(name="employe_valide_rejete_id", columns={"employe_valide_rejete_id"}), @ORM\Index(name="type_consultation", columns={"type_consultation"})})
 * @ORM\Entity
 */
class Consultation extends Entity
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @var float
     *
     * @ORM\Column(name="taux", type="float", precision=10, scale=0, nullable=true)
     */
    protected $taux;

    /**
     * @var string
     *
     * @ORM\Column(name="nature_consultation", type="string", nullable=false)
     */
    protected $natureConsultation;

    /**
     * @var string
     *
     * @ORM\Column(name="nature_affection", type="string", length=255, nullable=true)
     */
    protected $natureAffection;

    /**
     * @var float
     *
     * @ORM\Column(name="montant", type="float", precision=10, scale=0, nullable=false)
     */
    protected $montant = '0';

    /**
     * @var float
     *
     * @ORM\Column(name="montant_modif", type="float", precision=10, scale=0, nullable=true)
     */
    protected $montantModif;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="datetime", nullable=false)
     */
    protected $date;

    /**
     * @var string
     *
     * @ORM\Column(name="observations", type="string", length=255, nullable=true)
     */
    protected $observations;

    /**
     * @var string
     *
     * @ORM\Column(name="etat_consultation", type="string", nullable=false)
     */
    protected $etatConsultation = 'attente_validation';

    /**
     * @var string
     *
     * @ORM\Column(name="supprime", type="string", nullable=false)
     */
    protected $supprime = '-1';

    /**
     * @var \Entity\Visite
     *
     * @ORM\ManyToOne(targetEntity="Entity\Visite")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="visite_id", referencedColumnName="id")
     * })
     */
    protected $visite;

    /**
     * @var \Entity\Employe
     *
     * @ORM\ManyToOne(targetEntity="Entity\Employe")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="employe_valide_rejete_id", referencedColumnName="id")
     * })
     */
    protected $employeValideRejete;

    /**
     * @var \Entity\TypePrestation
     *
     * @ORM\ManyToOne(targetEntity="Entity\TypePrestation")
     * @ORM\JoinColumns({
     *   @ORM\JoinColumn(name="type_consultation", referencedColumnName="id")
     * })
     */
    protected $typeConsultation;



    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set taux
     *
     * @param float $taux
     *
     * @return Consultation
     */
    public function setTaux($taux)
    {
        $this->taux = $taux;

        return $this;
    }

    /**
     * Get taux
     *
     * @return float
     */
    public function getTaux()
    {
        return $this->taux;
    }

    /**
     * Set natureConsultation
     *
     * @param string $natureConsultation
     *
     * @return Consultation
     */
    public function setNatureConsultation($natureConsultation)
    {
        $this->natureConsultation = $natureConsultation;

        return $this;
    }

    /**
     * Get natureConsultation
     *
     * @return string
     */
    public function getNatureConsultation()
    {
        return $this->natureConsultation;
    }

    /**
     * Set natureAffection
     *
     * @param string $natureAffection
     *
     * @return Consultation
     */
    public function setNatureAffection($natureAffection)
    {
        $this->natureAffection = $natureAffection;

        return $this;
    }

    /**
     * Get natureAffection
     *
     * @return string
     */
    public function getNatureAffection()
    {
        return $this->natureAffection;
    }

    /**
     * Set montant
     *
     * @param float $montant
     *
     * @return Consultation
     */
    public function setMontant($montant)
    {
        $this->montant = $montant;

        return $this;
    }

    /**
     * Get montant
     *
     * @return float
     */
    public function getMontant()
    {
        return $this->montant;
    }

    /**
     * Set montantModif
     *
     * @param float $montantModif
     *
     * @return Consultation
     */
    public function setMontantModif($montantModif)
    {
        $this->montantModif = $montantModif;

        return $this;
    }

    /**
     * Get montantModif
     *
     * @return float
     */
    public function getMontantModif()
    {
        return $this->montantModif;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     *
     * @return Consultation
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set observations
     *
     * @param string $observations
     *
     * @return Consultation
     */
    public function setObservations($observations)
    {
        $this->observations = $observations;

        return $this;
    }

    /**
     * Get observations
     *
     * @return string
     */
    public function getObservations()
    {
        return $this->observations;
    }

    /**
     * Set etatConsultation
     *
     * @param string $etatConsultation
     *
     * @return Consultation
     */
    public function setEtatConsultation($etatConsultation)
    {
        $this->etatConsultation = $etatConsultation;

        return $this;
    }

    /**
     * Get etatConsultation
     *
     * @return string
     */
    public function getEtatConsultation()
    {
        return $this->etatConsultation;
    }

    /**
     * Set supprime
     *
     * @param string $supprime
     *
     * @return Consultation
     */
    public function setSupprime($supprime)
    {
        $this->supprime = $supprime;

        return $this;
    }

    /**
     * Get supprime
     *
     * @return string
     */
    public function getSupprime()
    {
        return $this->supprime;
    }

    /**
     * Set visite
     *
     * @param \Entity\Visite $visite
     *
     * @return Consultation
     */
    public function setVisite(\Entity\Visite $visite = null)
    {
        $this->visite = $visite;

        return $this;
    }

    /**
     * Get visite
     *
     * @return \Entity\Visite
     */
    public function getVisite()
    {
        return $this->visite;
    }

    /**
     * Set employeValideRejete
     *
     * @param \Entity\Employe $employeValideRejete
     *
     * @return Consultation
     */
    public function setEmployeValideRejete(\Entity\Employe $employeValideRejete = null)
    {
        $this->employeValideRejete = $employeValideRejete;

        return $this;
    }

    /**
     * Get employeValideRejete
     *
     * @return \Entity\Employe
     */
    public function getEmployeValideRejete()
    {
        return $this->employeValideRejete;
    }

    /**
     * Set typeConsultation
     *
     * @param \Entity\TypePrestation $typeConsultation
     *
     * @return Consultation
     */
    public function setTypeConsultation(\Entity\TypePrestation $typeConsultation = null)
    {
        $this->typeConsultation = $typeConsultation;

        return $this;
    }

    /**
     * Get typeConsultation
     *
     * @return \Entity\TypePrestation
     */
    public function getTypeConsultation()
    {
        return $this->typeConsultation;
    }
}
