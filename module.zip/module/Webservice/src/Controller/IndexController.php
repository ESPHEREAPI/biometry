<?php

namespace Webservice\Controller;

use Interop\Container\ContainerInterface;

use Custom\Mvc\Controller\BackOfficeCommonController;

use Application\Core\Utilitaire;
use Application\Manager\AdherentManager;
use Application\Manager\AyantDroitManager;
use Application\Manager\BackAuthManager;
use Application\Manager\PrestataireManager;


class IndexController extends BackOfficeCommonController
{  
   /**
     * @var \Interop\Container\ContainerInterface
     */
	protected $appliContainer; 
    
    /**
     * @var \Application\Manager\AdherentManager
     */
    protected $adherentManager;
    
    /**
     * @var \Application\Manager\AyantDroitManager
     */
    protected $ayantDroitManager;
    
    /**
     * @var \Application\Manager\BackAuthManager
     */
    protected $backAuthManager;
    
    /**
     * @var \Application\Manager\PrestataireManager
     */
    protected $prestataireManager;
	
	protected $tabEquiv = [
                        // Pour les consultations généralistes
                        "CG" => "CS0",
                        "CGJ" => "CS0",
                        "CGN" => "CS0",
        
                        // Pour les consultations spécialistes
                        "CS" => "CS1",
                        "CSJ" => "CS1",
                        "CSN" => "CS1",
        
        
                        // Pour les consultations spécialistes
                        "CP" => "CS2",
                        "CPJ" => "CS2",
                        "CPN" => "CS2",
        
                        // Pour les médicaments
                        "ME01" => "PH02"
                      ];
    
    public function __construct(ContainerInterface $appliContainer, AdherentManager $adherentManager, AyantDroitManager $ayantDroitManager,
                                BackAuthManager $backAuthManager, PrestataireManager $prestataireManager)
	{
        $this->appliContainer = $appliContainer;
        
		$this->adherentManager = $adherentManager;
		$this->ayantDroitManager = $ayantDroitManager;
		$this->backAuthManager = $backAuthManager;
		$this->prestataireManager = $prestataireManager;
	}
 
    
	
    public function indexAction ()
    {
        var_dump("iiiiiiiii"); exit;
    }
    
    public function recupererDonneesAdherentAction ()
    {
        set_time_limit(86400);
        ini_set('memory_limit','256000M');
        
        
        $error = "";
        $utilitaire = new Utilitaire;
        

        $police = $this->params()->fromRoute('police', null);

        $postValues = array_merge_recursive(
            $this->getRequest()->getPost()->toArray(),
            $this->getRequest()->getFiles()->toArray()
            );
        
        $appliConfig =  new \Application\Core\AppliConfig();
        $webserviceServer = $appliConfig->get("webservice_server");
        
        
        $requete_params = array();
        
        // Initialise notre session cURL. On lui donne la requête à exécuter
        $ch = curl_init();
        
        //set option of URL to post to
        curl_setopt($ch, CURLOPT_URL, "http://".$webserviceServer["ip_adress"]."/web_service/public/biometry/get-liste-adherent");
        //set option of request method -----HTTP POST Request
        curl_setopt($ch, CURLOPT_POST, true);
        //The HTTP authentication methods to use
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
        //This line sets the parameters to post to the URL
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requete_params);
        //This line makes sure that the response is gotten back to the
        // $response object(see below) and not echoed
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        
        

        // On lance l'exécution de la requête URL.
        if($response = curl_exec($ch)) // Si elle s'est exécutée correctement
        {
        	
        	if(empty($response) || $response == "null")
        	{
        		$error = $this->getTranslator("Transaction non initialisee");
        	}
        	else
        	{
        		// object
        		$returnCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        		//Check if there are no errors ie httpresponse == 200 -OK
        		if ($returnCode == 200) {
        			//If there are no errors, the transaction ID is returned
        			$varRetour = json_decode($response, true);
        			$error = $varRetour['error'];
        			$tabAdherent = $varRetour['tabAdherent'];
        			
        			if(!empty($error))
        			{
        			    
        			}
        			else
        			{
        			    $ligneNonInserees = array();
        			    
        			    foreach ($tabAdherent as $unAdherent)
        			    {
        			        $nouveauElement = false;
        			        $unAdherentTravaille = array();
        			        foreach ($unAdherent as $key => $value)
        			        {
        			            if(!empty($value))
        			                $value = trim($value);
        			                
        			            $unAdherentTravaille[$utilitaire->to_camel_case(strtolower($key))] = $value;
                            }
                            
                            if($police && $police != $unAdherentTravaille['police'])
                            {
                                continue;
                            }

        			        
        			        $unAdherentTravaille['codeAdherent'] = $unAdherentTravaille['codeAssure']."_".$unAdherentTravaille['police'];
        			        
        			        
        			        if(!empty($unAdherentTravaille['naissance']))
        			        {
        			            $unAdherentTravaille['naissance'] = str_replace(" ", "", $unAdherentTravaille['naissance']);
        			        }
        			        if(!empty($unAdherentTravaille['effetPolice']))
        			        {
        			            $unAdherentTravaille['effetPolice'] = str_replace(" ", "", $unAdherentTravaille['effetPolice']);
        			        }
        			        if(!empty($unAdherentTravaille['echeancePolice']))
        			        {
        			            $unAdherentTravaille['echeancePolice'] = str_replace(" ", "", $unAdherentTravaille['echeancePolice']);
        			        }
        			        
        			        
        			        $adherent = $this->getEntityManager()->find('Entity\Adherent', $unAdherentTravaille['codeAdherent']);
        			        if(!$adherent)
        			        {
        			            $adherent = new \Entity\Adherent;
        			            $nouveauElement = true;
        			        }
        			        
        			        $adherent->exchangeArray($unAdherentTravaille);
        			        
        			        if(!empty($unAdherentTravaille['naissance']))
        			        {
        			            $adherent->setNaissance(new \DateTime($unAdherentTravaille['naissance']));
        			        }
        			        if(!empty($unAdherentTravaille['effetPolice']))
        			        {
        			            $adherent->setEffetPolice(new \DateTime($unAdherentTravaille['effetPolice']));
        			        }
        			        if(!empty($unAdherentTravaille['echeancePolice']))
        			        {
        			            $adherent->setEcheancePolice(new \DateTime($unAdherentTravaille['echeancePolice']));
        			        }
        			        
        			        
        			        try {
        			            
        			            if($nouveauElement)
        			            {
        			                $this->getEntityManager()->persist($adherent);
        			            }
        			            
        			            $this->getEntityManager()->flush();
        			            
        			        } catch (\Exception $e) {
        			            $unAdherentTravaille["messageErreur"] = $e->getMessage();
        			            $ligneNonInserees[] = $unAdherentTravaille;
        			        }
        			    }
        			    
        			    
        			    if(count($ligneNonInserees))
        			    {
        			        $contenuFichier = "";
        			        foreach ($ligneNonInserees as $uneLigne)
        			        {
        			            if($contenuFichier != "")
        			            {
        			                $contenuFichier .=  "\n";
        			            }
        			               
        			            $contenuFichier .= json_encode($uneLigne);
        			        }
        			            
        			        
        			        $myfile = fopen(__DIR__."/../../../../public/docs/log/echec_insertion/echec_adherent_".date("Y-m-d-H-i-s").".txt", "w");
        			        

        			        fwrite($myfile, $contenuFichier);
        			       
        			        fclose($myfile);
        			    }
        			}
        		}
        		else
        		{
        			
        			$error = $this->getTranslator("Erreur de communication avec le serveur")." : <b>".$returnCode."</b>";
        		}
        	}
        }
        else // S'il y a une erreur, on affiche "Erreur", suivi du détail de l'erreur.
        {
        	$error =  curl_error($ch);
        }
        
        // On ferme notre session cURL.
        curl_close($ch);
        
        
        var_dump($error);
        exit;
    }
    
    public function recupererDonneesAyantDroitAction ()
    {
        set_time_limit(86400);
        ini_set('memory_limit','256000M');
        
        $error = "";
        $utilitaire = new Utilitaire;
        

        $codeAdherentFromRoute = $this->params()->fromRoute('codeAdherent', null);

        $postValues = array_merge_recursive(
            $this->getRequest()->getPost()->toArray(),
            $this->getRequest()->getFiles()->toArray()
            );
        
        $appliConfig =  new \Application\Core\AppliConfig();
        $webserviceServer = $appliConfig->get("webservice_server");
        
        
        $requete_params = array();
        
        // Initialise notre session cURL. On lui donne la requête à exécuter
        $ch = curl_init();
        
        //set option of URL to post to
        curl_setopt($ch, CURLOPT_URL, "http://".$webserviceServer["ip_adress"]."/web_service/public/biometry/get-liste-ayant-droit");
        //set option of request method -----HTTP POST Request
        curl_setopt($ch, CURLOPT_POST, true);
        //The HTTP authentication methods to use
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
        //This line sets the parameters to post to the URL
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requete_params);
        //This line makes sure that the response is gotten back to the
        // $response object(see below) and not echoed
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        
        
        
        // On lance l'exécution de la requête URL.
        if($response = curl_exec($ch)) // Si elle s'est exécutée correctement
        {
            
            if(empty($response) || $response == "null")
            {
                $error = $this->getTranslator("Transaction non initialisee");
            }
            else
            {
                // object
                $returnCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                
                //Check if there are no errors ie httpresponse == 200 -OK
                if ($returnCode == 200) {
                    //If there are no errors, the transaction ID is returned
                    $varRetour = json_decode($response, true);
                    $error = $varRetour['error'];
                    $tabAyantDroit = $varRetour['tabAyantDroit'];
                    
                    if(!empty($error))
                    {
                        
                    }
                    else
                    {
                        $ligneNonInserees = array();
                        
                        // var_dump(count($tabAyantDroit)); exit;
                        
                        foreach ($tabAyantDroit as $unAyantDroit)
                        {
                            $nouveauElement = false;
                            $unAyantDroitTravaille = array();
                            foreach ($unAyantDroit as $key => $value)
                            {
                                if(!empty($value))
                                    $value = trim($value);
                                    
                                    $unAyantDroitTravaille[$utilitaire->to_camel_case(strtolower($key))] = $value;
                            }
                            
                            
                            $codeAdherent = $unAyantDroitTravaille['codeAssure']."_".$unAyantDroitTravaille['police'];
                            
                            
                            if($codeAdherentFromRoute && $codeAdherentFromRoute != $codeAdherent)
                            {
                                continue;
                            }
                            
                            
                            $adherent = $this->getEntityManager()->find('Entity\Adherent', $codeAdherent);
                            if($adherent)
                            {
                                // var_dump($unAyantDroit);
                                
                                $unAyantDroitTravaille['codeAyantDroit'] = $codeAdherent."_".$unAyantDroitTravaille['codeAyantD'];
                                $unAyantDroitTravaille['codeAdherent'] = $codeAdherent;
                                $unAyantDroitTravaille['nom'] = $unAyantDroitTravaille['ayantsDroits'];
                                
                                
                                if(!empty($unAyantDroitTravaille['naissance']))
                                {
                                    $unAyantDroitTravaille['naissance'] = str_replace(" ", "", $unAyantDroitTravaille['naissance']);
                                }
                                
                                $ayantDroit = $this->getEntityManager()->find('Entity\AyantDroit', $unAyantDroitTravaille['codeAyantDroit']);
                                if(!$ayantDroit)
                                {
                                    $ayantDroit = new \Entity\AyantDroit;
                                    $nouveauElement = true;
                                }
                                
                                $ayantDroit->exchangeArray($unAyantDroitTravaille);
                                
                                if(!empty($unAyantDroitTravaille['naissance']))
                                {
                                    $ayantDroit->setNaissance(new \DateTime($unAyantDroitTravaille['naissance']));
                                }
                                
                                $ayantDroit->setCodeAdherent($adherent);

                                try {
                                    
                                    if($nouveauElement)
                                    {
                                        $this->getEntityManager()->persist($ayantDroit);
                                    }
                                    
                                    $this->getEntityManager()->flush();
                                    
                                } catch (\Exception $e) {
                                    $ligneNonInserees[] = $unAyantDroitTravaille;
                                }
                            }
                        }
                        
                        
                        if(count($ligneNonInserees))
                        {
                            $contenuFichier = "";
                            foreach ($ligneNonInserees as $uneLigne)
                            {
                                if($contenuFichier != "")
                                {
                                    $contenuFichier .=  "\n";
                                }
                                
                                $contenuFichier .= json_encode($uneLigne);
                            }
                            
                            
                            $myfile = fopen(__DIR__."/../../../../public/docs/log/echec_insertion/echec_ayant_droit_".date("Y-m-d-H-i-s").".txt", "w");
                            
                            
                            fwrite($myfile, $contenuFichier);
                            
                            fclose($myfile);
                        }
                    }
                }
                else
                {
                    
                    $error = $this->getTranslator("Erreur de communication avec le serveur")." : <b>".$returnCode."</b>";
                }
            }
        }
        else // S'il y a une erreur, on affiche "Erreur", suivi du détail de l'erreur.
        {
            $error =  curl_error($ch);
        }
        
        // On ferme notre session cURL.
        curl_close($ch);
        
        
        var_dump($error);
        exit;
    } 
    
    public function recupererDonneesTauxPrestationAction ()
    {
        set_time_limit(86400);
        ini_set('memory_limit','256000M');
        
        $utilitaire = new Utilitaire;
        
        $postValues = array_merge_recursive(
            $this->getRequest()->getPost()->toArray(),
            $this->getRequest()->getFiles()->toArray()
            );
        
        $appliConfig =  new \Application\Core\AppliConfig();
        $webserviceServer = $appliConfig->get("webservice_server");
        
        
        $requete_params = array();
        
        // Initialise notre session cURL. On lui donne la requête à exécuter
        $ch = curl_init();
        
        //set option of URL to post to
        curl_setopt($ch, CURLOPT_URL, "http://".$webserviceServer["ip_adress"]."/web_service/public/biometry/get-liste-taux-prestation");
        //set option of request method -----HTTP POST Request
        curl_setopt($ch, CURLOPT_POST, true);
        //The HTTP authentication methods to use
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
        //This line sets the parameters to post to the URL
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requete_params);
        //This line makes sure that the response is gotten back to the
        // $response object(see below) and not echoed
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        
        
        // On lance l'exécution de la requête URL.
        if($response = curl_exec($ch)) // Si elle s'est exécutée correctement
        {
            
            if(empty($response) || $response == "null")
            {
                $error = $this->getTranslator("Transaction non initialisee");
            }
            else
            {
                // object
                $returnCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                
                //Check if there are no errors ie httpresponse == 200 -OK
                if ($returnCode == 200) {
                    //If there are no errors, the transaction ID is returned
                    $varRetour = json_decode($response, true);
                    $error = $varRetour['error'];
                    $tabTauxPrestation = $varRetour['tabTauxPrestation'];
                    
                    if(!empty($error))
                    {
                        
                    }
                    else
                    {
                        // var_dump($tabTauxPrestation); exit;
                        
                        $tabTypePrestation = array();
                        
                        $ligneNonInserees = array();
                        
                        foreach ($tabTauxPrestation as $unTauxPrestation)
                        {
                            $nouveauElement = false;
                            $unTauxPrestationTravaille = array();
//                             foreach ($unTauxPrestation as $key => $value)
//                             {
//                                 if(!empty($value))
//                                     $value = trim($value);
                                    
//                                     $unTauxPrestationTravaille[$utilitaire->to_camel_case(strtolower($key))] = $value;
//                             }


                            if(!isset($unTauxPrestation['CODEPRES']) || empty($unTauxPrestation['CODEPRES']) ||
                               !isset($unTauxPrestation['CODEINTE']) || empty($unTauxPrestation['CODEINTE']) ||
                               !isset($unTauxPrestation['NUMEPOLI']) || empty($unTauxPrestation['NUMEPOLI']) ||
                               !isset($unTauxPrestation['NUMEGROU']) || empty($unTauxPrestation['NUMEGROU']) ||
                               !isset($unTauxPrestation['TYPCONSU']) || empty($unTauxPrestation['TYPCONSU']))
                            {
                                $ligneNonInserees[] = $unTauxPrestation;
                                continue;
                            }
							
							if(array_key_exists($unTauxPrestation['CODEPRES'], $this->tabEquiv))
                            {
                                $unTauxPrestation['CODEPRES'] = $this->tabEquiv[$unTauxPrestation['CODEPRES']];
                            }                            
                            
                            if(!isset($unTauxPrestation['TAUXCOUV']) || empty($unTauxPrestation['TYPCONSU']))
                            {
                                $unTauxPrestation['TAUXCOUV'] = null;
                            }
                            else
                            {
                                $unTauxPrestation['TAUXCOUV'] = trim($unTauxPrestation['TAUXCOUV']);
                            }
                            
                            if(!isset($unTauxPrestation['VALEPLAF']) || empty($unTauxPrestation['VALEPLAF']))
                            {
                                $unTauxPrestation['VALEPLAF'] = null;
                            }
                            else
                            {
                                $unTauxPrestation['VALEPLAF'] = trim($unTauxPrestation['VALEPLAF']);
                            }
                            
                            $unTauxPrestationTravaille['typePrestation'] = trim($unTauxPrestation['CODEPRES']);
                            $unTauxPrestationTravaille['police'] = trim($unTauxPrestation['CODEINTE']."-".trim($unTauxPrestation['NUMEPOLI']));
                            $unTauxPrestationTravaille['groupe'] = trim($unTauxPrestation['NUMEGROU']);
                            $unTauxPrestationTravaille['taux'] = $unTauxPrestation['TAUXCOUV'];
                            $unTauxPrestationTravaille['plafond'] = $unTauxPrestation['VALEPLAF'];
                            
                            
                            
                            $typePrestation = $this->getEntityManager()->find('Entity\TypePrestation', $unTauxPrestationTravaille['typePrestation']);
                            if(!$typePrestation)
                            {
                                $unTypePrestationTravaille = array("id" => $unTauxPrestationTravaille['typePrestation'], "nom" => trim($unTauxPrestation['TYPCONSU']));
                                
                                $typePrestation = new \Entity\TypePrestation();
                                $typePrestation->exchangeArray($unTypePrestationTravaille);
                                
                                try {
                                    
                                    $this->getEntityManager()->persist($typePrestation);
                                    
                                    $this->getEntityManager()->flush();
                                    
                                } catch (\Exception $e) {
                                    $ligneNonInserees[] = $unTypePrestationTravaille;
                                }
                            }
                            
                            
                            $paramsTypePrestation = array('typePrestation' => $unTauxPrestationTravaille['typePrestation'],
                                                          "police" => $unTauxPrestationTravaille['police'],
                                                          "groupe" => $unTauxPrestationTravaille['groupe']);
                            
                            
                            $tauxPrestation = $this->getEntityManager()->getRepository('Entity\TauxPrestation')->findOneBy($paramsTypePrestation);
                            if(!$tauxPrestation)
                            {
                                $tauxPrestation = new \Entity\TauxPrestation;
                                $nouveauElement = true;
                            }
//                             else
//                             {
//                                 var_dump($paramsTypePrestation);
//                             }
                            
                            $tauxPrestation->exchangeArray($unTauxPrestationTravaille);
                            $tauxPrestation->setTypePrestation($typePrestation);
                            
                            
                            try {
                                
                                if($nouveauElement)
                                {
                                    $this->getEntityManager()->persist($tauxPrestation);
                                }
                                
                                $this->getEntityManager()->flush();
                                
                            } catch (\Exception $e) {
                                $ligneNonInserees[] = $unTauxPrestationTravaille;
                            }
                        }
                        
                        
                        if(count($ligneNonInserees))
                        {
                            $contenuFichier = "";
                            foreach ($ligneNonInserees as $uneLigne)
                            {
                                if($contenuFichier != "")
                                {
                                    $contenuFichier .=  "\n";
                                }
                                
                                $contenuFichier .= json_encode($uneLigne);
                            }
                            
                            
                            $myfile = fopen(__DIR__."/../../../../public/docs/log/echec_insertion/echec_tauxPrestation_".date("Y-m-d-H-i-s").".txt", "w");
                            
                            
                            fwrite($myfile, $contenuFichier);
                            
                            fclose($myfile);
                        }
                    }
                }
                else
                {
                    
                    $error = $this->getTranslator("Erreur de communication avec le serveur")." : <b>".$returnCode."</b>";
                }
            }
        }
        else // S'il y a une erreur, on affiche "Erreur", suivi du détail de l'erreur.
        {
            $error =  curl_error($ch);
        }
        
        // On ferme notre session cURL.
        curl_close($ch);
        
        
        var_dump($error);
        exit;
    }
    
    
    public function getListeAdherentAction()
    {
        // header("Content-Type:application/json");
        
        if(!empty($_GET["noms"]))
        {
            $noms = $_GET["noms"];
            $items = $this->getItems($noms);
            if(empty($items))
            {
                $this->jsonResponse(200, "Adherent introuvable", NULL);
            } 
            else 
            {
                $this->jsonResponse(200, "Adherent trouve", $items);
            }
        } 
        else 
        {
            $this->jsonResponse(400, "requete invalide", NULL);
        }
        
        exit;
    }
    
    public function genererVisiteAction()
    {
        $utilitaire = new Utilitaire();
        $statusMessage = "";
        $status = 200;
        $visiteArray = null;
		
		$dateServeur= date("Y-m-d");
		//var_dump($dateServeur);exit();
		
        
        if(empty($_GET["codeAdherent"]))
        {
            $status = 400;
            $statusMessage .= $this->getTranslator("Veuillez spécifier le code de l'adherent\n");
        }
        if(empty($_GET["prestataire"]))
        {
            $status = 400;
            $statusMessage .= $this->getTranslator("Veuillez spécifier le prestataire\n");
        }
        if(empty($_GET["telephone"]))
        {
            $status = 400;
            $statusMessage .= $this->getTranslator("Veuillez spécifier le numero de telephone\n");
        }
        
        if($status == 200)
        {
            $ayantDroit = null;
            $adherent = $this->getEntityManager()->find('Entity\Adherent', trim($_GET["codeAdherent"]));
            $prestataire = $this->getEntityManager()->find('Entity\Prestataire', trim($_GET["prestataire"]));
            $telephone = trim($_GET["telephone"]);
            if(!empty($_GET["codeAyantDroit"]))
            {
                if($_GET["codeAyantDroit"] != null && $_GET["codeAyantDroit"] != "null")
                {
                    $ayantDroit = $this->getEntityManager()->find('Entity\AyantDroit', trim($_GET["codeAyantDroit"]));
                    if(!$ayantDroit)
                    {
                        $status = 400;
                        $statusMessage .= $this->getTranslator("Impossible de trouver l'ayant droit ".$_GET["codeAyantDroit"]."\n");
                    }
                }
            }
            
            
            if(!$adherent)
            {
                $status = 400;
                $statusMessage .= $this->getTranslator("Impossible de trouver l'adherent\n");
            }
            elseif($adherent->getStatut() == "-1")
            {
                $status = 400;
                $statusMessage .= $this->getTranslator("Le contrat de l'assure a ete suspendu\nQu'il contacte le souscripteur du contrat\n");
            }
			elseif(!empty($adherent->getEcheancePolice()) && $adherent->getEcheancePolice()->format("Y-m-d") < $dateServeur)
            {
                $status = 400;
                $statusMessage .= $this->getTranslator("Le contrat de l'assure a expire\n");
            }
            
            if(!$prestataire)
            {
                $status = 400;
                $statusMessage .= $this->getTranslator("Impossible de trouver le prestataire\n");
            }
            
            
            if($status == 200)
            {
                // Debut du mode transactionnel
                $this->getEntityManager()->getConnection()->beginTransaction(); // On suspend l'auto-commit
                try {
                    $paramsCodeVisite = $this->genererCodeVisite($prestataire->getId());
                    $idVisite = $paramsCodeVisite['idVisite'];
                    $codeCourtVisite = $paramsCodeVisite['codeCourtVisite'];
                    
                    $visite = new \Entity\Visite;
                    $visiteArray = array("id" => $idVisite,
                        "codeAdherent" => $adherent,
                        "codeAyantDroit" => $ayantDroit,
                        "prestataire" => $prestataire,
                        "codeCourt" => $codeCourtVisite,
                        "telephone" => $telephone,
                        "date" => new \DateTime(date("Y-m-d H:i:s")),
                    );
                    $visite->exchangeArray($visiteArray);
                    
                    
                    
                    
                    
                    $this->getEntityManager()->persist($visite);
                    $this->getEntityManager()->flush();
                    
                    $this->getEntityManager()->getConnection()->commit();
                    
                    
                    $codeAyantDroit = null;
                    if($ayantDroit)
                    {
                        $codeAyantDroit = $ayantDroit->getCodeAyantDroit();
                    }
                    
                    $visiteArray = array("id" => $codeCourtVisite,
                        "codeAdherent" => $adherent->getCodeAdherent(),
                        "codeAyantDroit" => $codeAyantDroit,
                        "prestataire" => $prestataire->getId(),
                    );
                    
                    
                } catch (\Exception $e) {
                    $this->getEntityManager()->getConnection()->rollback();
                    $this->getEntityManager()->close();
                    $status = 400;
                    $statusMessage .= $this->getTranslator("Probleme lors de l'enregistrement\n");
                }
                
                if($status == 200)
                {
                    try {
                        
                        $prestataire->afficheChaine();
                        
                        $contenuSms = $this->getTranslator("Centre hospitalier :")." ".$prestataire->getNom()."\n";
                        $contenuSms .= $this->getTranslator("Code de la visite :")." ".$codeCourtVisite."\n";
                        $contenuSms .= $this->getTranslator("Ce code sera utilise tout au long du processus.");
                        
                        $utilitaire->sendSmsHttp(array($telephone), $contenuSms);
                    } catch (\Exception $e) {
                        
                    }
                }
            }
        }
        
        $this->jsonResponse($status, $statusMessage, $visiteArray);
        
        exit;
    }
    
    
    public function getListeAyantDroitAction()
    {
        $statusMessage = "";
        $status = 200;
        $tabAyantDroitRetour = null;
        
        if(empty($_GET["codeAdherent"]))
        {
            $status = 400;
            $statusMessage .= $this->getTranslator("Veuillez spécifier le code de l'adherent\n");
        }
        
        if($status == 200)
        {
            $tabParams = array(
                            "codeAdherent" => trim($_GET["codeAdherent"]),
                            "statut" => "1"
                        );
            
            
            $tabAyantDroit = $this->ayantDroitManager->getListeAyantDroitTabParams($tabParams);
            $tabAyantDroitRetour = array();
            if(count($tabAyantDroit) > 0)
            {
                foreach ($tabAyantDroit as $unAyantDroit)
                {
                    $dateNaissanceAyantDroit = "";
                    if($unAyantDroit->getNaissance())
                    {
                        $dateNaissanceAyantDroit = $unAyantDroit->getNaissance()->format("d/m/Y");
                    }
                    
                    $tabAyantDroitRetour[] = array("codeAyantDroit" => $unAyantDroit->getCodeAyantDroit(),
                                                   "codeAdherent" => $unAyantDroit->getCodeAdherent()->getCodeAdherent(),
                                                   "nom" => $unAyantDroit->getNom(),
                                                   "sexe" => $unAyantDroit->getSexe(),
                                                   "naissance" => $dateNaissanceAyantDroit,
                                                   "police" => $unAyantDroit->getPolice()
                    );
                }
            }
        }
        
        $this->jsonResponse($status, $statusMessage, $tabAyantDroitRetour);
        
        exit;
    }
    
    public function setAdherentEnroleAction()
    {
        $statusMessage = "";
        $status = 200;
        $data = "-1";
        
        if(empty($_GET["codeAdherent"]))
        {
            $status = 400;
            $statusMessage .= $this->getTranslator("Veuillez spécifier le code de l'adherent\n");
        }
        
        if($status == 200)
        {
            $adherent = $this->getEntityManager()->find('Entity\Adherent', trim($_GET["codeAdherent"]));
            if(!$adherent)
            {
                $status = 400;
                $statusMessage .= $this->getTranslator("Impossible de trouver l'adherent\n");
            }
            
            if($status == 200)
            {
                $adherent->setEnrole("1");
                
                try {
                    
                    $this->getEntityManager()->flush();
                    $data = "1";
                    
                } catch (\Exception $e) {
                    $status = 400;
                    $statusMessage .= $this->getTranslator("Problème lors de la mise à jour du statut de l'enrolement\n");
                }
                
            }
        }
        
        $this->jsonResponse($status, $statusMessage, $data);
        
        exit;
    }
    
    public function connexionAction()
    {
        $statusMessage = "";
        $status = 200;
        $data = "-1";
        
        if(empty($_GET["login"]) || empty($_GET["motPasse"]))
        {
            $status = 400;
            $statusMessage .= $this->getTranslator("Veuillez specifier le login (ou l'adresse mail) et le mot de passe");
        }
        
        if($status == 200)
        {
            $userConnect = $this->backAuthManager->connexion(trim($_GET["login"]), trim($_GET["motPasse"]));
            if(!$userConnect)
            {
                $status = 400;
                $statusMessage .= $this->getTranslator("Login or password incorrect");
            }
            else
            {
                $data = "1";
            }
        }
        
        $this->jsonResponse($status, $statusMessage, $data);
        
        exit;
    }  
    
    public function viderDonneesUnPrestataireAction()
    {
        $varRetour = array("succes" => true, "error" => "");
        
        var_dump($varRetour); exit;
        
        $idPrestataire = $this->params()->fromRoute('idPrestataire', null);
        if(empty($idPrestataire))
        {
            $varRetour["succes"] = false;
            $varRetour["error"] = $this->getTranslator("Veuillez renseigner le prestataire dans l'url");
        }
        else
        {
            $prestataire = $this->getEntityManager()->find('Entity\Prestataire', $idPrestataire);
            if(!$prestataire)
            {
                $varRetour["succes"] = false;
                $varRetour["error"] = $this->getTranslator("Impossible de trouver le prestataire, verifiez que le code du prestataire est correct");
            }
            else
            {
                $varRetour = $this->prestataireManager->viderDonneesUnPrestataire($prestataire);
            }
        }
        
        echo json_encode($varRetour);
        exit;
    }

    
    public function viderDonneesUneVisiteAction()
    {
        $varRetour = array("succes" => true, "error" => "");
        
        var_dump($varRetour); exit;
        
        $idVisite = $this->params()->fromRoute('idVisite', null);
        if(empty($idVisite))
        {
            $varRetour["succes"] = false;
            $varRetour["error"] = $this->getTranslator("Veuillez renseigner la visite dans l'url");
        }
        else
        {
            $visite = $this->getEntityManager()->find('Entity\Visite', $idVisite);
            if(!$visite)
            {
                $varRetour["succes"] = false;
                $varRetour["error"] = $this->getTranslator("Impossible de trouver la visite, verifiez que le code de la visite est correct");
            }
            else
            {
                $varRetour = $this->prestataireManager->viderDonneesUneVisite($visite);
            }
        }
        
        echo json_encode($varRetour);
        exit;
    }

    public function desactiverDonneesAdherentAction()
    {
        set_time_limit(86400);
        ini_set('memory_limit','256000M');
        
        
        $error = "";
        $utilitaire = new Utilitaire;
        

        $police = $this->params()->fromRoute('police', null);

        $postValues = array_merge_recursive(
            $this->getRequest()->getPost()->toArray(),
            $this->getRequest()->getFiles()->toArray()
            );
        
        $appliConfig =  new \Application\Core\AppliConfig();
        $webserviceServer = $appliConfig->get("webservice_server");
        
        
        $requete_params = array();
        
        // Initialise notre session cURL. On lui donne la requête à exécuter
        $ch = curl_init();
        
        //set option of URL to post to
        curl_setopt($ch, CURLOPT_URL, "http://".$webserviceServer["ip_adress"]."/web_service/public/biometry/get-liste-adherent");
        //set option of request method -----HTTP POST Request
        curl_setopt($ch, CURLOPT_POST, true);
        //The HTTP authentication methods to use
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
        //This line sets the parameters to post to the URL
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requete_params);
        //This line makes sure that the response is gotten back to the
        // $response object(see below) and not echoed
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        
        

        // On lance l'exécution de la requête URL.
        if($response = curl_exec($ch)) // Si elle s'est exécutée correctement
        {
        	
        	if(empty($response) || $response == "null")
        	{
        		$error = $this->getTranslator("Transaction non initialisee");
        	}
        	else
        	{
        		// object
        		$returnCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        		//Check if there are no errors ie httpresponse == 200 -OK
        		if ($returnCode == 200) {
        			//If there are no errors, the transaction ID is returned
        			$varRetour = json_decode($response, true);
        			$error = $varRetour['error'];
        			$tabAdherent = $varRetour['tabAdherent'];
        			
        			if(empty($error))
        			{
        			    $tabAdherentTravaille = array();
        			    foreach ($tabAdherent as $unAdherent)
        			    {
        			        $unAdherentTravaille = array();
        			        foreach ($unAdherent as $key => $value)
        			        {
        			            if(!empty($value))
        			                $value = trim($value);
        			                
        			            $unAdherentTravaille[$utilitaire->to_camel_case(strtolower($key))] = $value;
                            }
                            
                            if($police && $police != $unAdherentTravaille['police'])
                            {
                                continue;
                            }

        			        
        			        $unAdherentTravaille['codeAdherent'] = $unAdherentTravaille['codeAssure']."_".$unAdherentTravaille['police'];
        			        
        			        
        			        if(!empty($unAdherentTravaille['naissance']))
        			        {
        			            $unAdherentTravaille['naissance'] = str_replace(" ", "", $unAdherentTravaille['naissance']);
        			        }
        			        if(!empty($unAdherentTravaille['effetPolice']))
        			        {
        			            $unAdherentTravaille['effetPolice'] = str_replace(" ", "", $unAdherentTravaille['effetPolice']);
        			        }
        			        if(!empty($unAdherentTravaille['echeancePolice']))
        			        {
        			            $unAdherentTravaille['echeancePolice'] = str_replace(" ", "", $unAdherentTravaille['echeancePolice']);
        			        }
                            
                            $tabAdherentTravaille[$unAdherentTravaille['codeAdherent']] = $unAdherentTravaille;
                        }
                        

                        $tabAdherentBd = $this->getEntityManager()->getRepository('Entity\Adherent')->findBy(array(
                            'statut' => '1'
                        ));

                        foreach($tabAdherentBd as $unAdherentBd)
                        {
                            if(!array_key_exists($unAdherentBd->getCodeAdherent(), $tabAdherentTravaille))
                            {
                                $unAdherentBd->setStatut("-1");
                            }
                        }

                        $this->getEntityManager()->flush();
        			}
        		}
        		else
        		{
        			$error = $this->getTranslator("Erreur de communication avec le serveur")." : <b>".$returnCode."</b>";
        		}
        	}
        }
        else // S'il y a une erreur, on affiche "Erreur", suivi du détail de l'erreur.
        {
        	$error =  curl_error($ch);
        }
        
        // On ferme notre session cURL.
        curl_close($ch);
        
        
        var_dump($error);
        exit;
    }

    public function desactiverDonneesAyantDroitAction()
    {
        set_time_limit(86400);
        ini_set('memory_limit','256000M');
        
        $error = "";
        $utilitaire = new Utilitaire;
        

        $codeAdherentFromRoute = $this->params()->fromRoute('codeAdherent', null);

        $postValues = array_merge_recursive(
            $this->getRequest()->getPost()->toArray(),
            $this->getRequest()->getFiles()->toArray()
            );
        
        $appliConfig =  new \Application\Core\AppliConfig();
        $webserviceServer = $appliConfig->get("webservice_server");
        
        
        $requete_params = array();
        
        // Initialise notre session cURL. On lui donne la requête à exécuter
        $ch = curl_init();
        
        //set option of URL to post to
        curl_setopt($ch, CURLOPT_URL, "http://".$webserviceServer["ip_adress"]."/web_service/public/biometry/get-liste-ayant-droit");
        //set option of request method -----HTTP POST Request
        curl_setopt($ch, CURLOPT_POST, true);
        //The HTTP authentication methods to use
        curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
        //This line sets the parameters to post to the URL
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requete_params);
        //This line makes sure that the response is gotten back to the
        // $response object(see below) and not echoed
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        
        
        
        // On lance l'exécution de la requête URL.
        if($response = curl_exec($ch)) // Si elle s'est exécutée correctement
        {
            
            if(empty($response) || $response == "null")
            {
                $error = $this->getTranslator("Transaction non initialisee");
            }
            else
            {
                // object
                $returnCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                
                //Check if there are no errors ie httpresponse == 200 -OK
                if ($returnCode == 200) {
                    //If there are no errors, the transaction ID is returned
                    $varRetour = json_decode($response, true);
                    $error = $varRetour['error'];
                    $tabAyantDroit = $varRetour['tabAyantDroit'];
                    
                    if(empty($error))
                    {
                        $tabAyantDroitTravaille = array();
                        foreach ($tabAyantDroit as $unAyantDroit)
                        {
                            $unAyantDroitTravaille = array();
                            foreach ($unAyantDroit as $key => $value)
                            {
                                if(!empty($value))
                                    $value = trim($value);
                                    
                                    $unAyantDroitTravaille[$utilitaire->to_camel_case(strtolower($key))] = $value;
                            }
                            
                            
                            $codeAdherent = $unAyantDroitTravaille['codeAssure']."_".$unAyantDroitTravaille['police'];
                            
                            
                            if($codeAdherentFromRoute && $codeAdherentFromRoute != $codeAdherent)
                            {
                                continue;
                            }
                            
                            
                            $adherent = $this->getEntityManager()->find('Entity\Adherent', $codeAdherent);
                            if($adherent)
                            {
                                // var_dump($unAyantDroit);
                                
                                $unAyantDroitTravaille['codeAyantDroit'] = $codeAdherent."_".$unAyantDroitTravaille['codeAyantD'];
                                $unAyantDroitTravaille['codeAdherent'] = $codeAdherent;
                                $unAyantDroitTravaille['nom'] = $unAyantDroitTravaille['ayantsDroits'];
                                
                                
                                if(!empty($unAyantDroitTravaille['naissance']))
                                {
                                    $unAyantDroitTravaille['naissance'] = str_replace(" ", "", $unAyantDroitTravaille['naissance']);
                                }

                                if($adherent->getStatut() == "1")
                                {
                                    $tabAyantDroitTravaille[$unAyantDroitTravaille['codeAyantDroit']] = $unAyantDroitTravaille;
                                }
                            }
                        }



                        $tabAyantDroitBd = $this->getEntityManager()->getRepository('Entity\AyantDroit')->findBy(array(
                            'statut' => '1'
                        ));

                        foreach($tabAyantDroitBd as $unAyantDroitBd)
                        {
                            if(!array_key_exists($unAyantDroitBd->getCodeAyantDroit(), $tabAyantDroitTravaille))
                            {
                                $unAyantDroitBd->setStatut("-1");
                            }
                        }

                        $this->getEntityManager()->flush();
                    }
                }
                else
                {
                    $error = $this->getTranslator("Erreur de communication avec le serveur")." : <b>".$returnCode."</b>";
                }
            }
        }
        else // S'il y a une erreur, on affiche "Erreur", suivi du détail de l'erreur.
        {
            $error =  curl_error($ch);
        }
        
        // On ferme notre session cURL.
        curl_close($ch);
        
        
        var_dump($error);
        exit;
    }



    
    function jsonResponse($status, $status_message, $data)
    {
        $response['status'] = $status;
        $response['status_message'] = $status_message;
        $response['data'] = $data;
        $json_response = json_encode($response,JSON_UNESCAPED_UNICODE);
        //var_dump($json_response);
        echo $json_response;
    }
    
    function getItems($noms)
    {
        if(empty($noms))
            return array();

        $tabParams = array(
                        "assurePrincipal" => $noms,
                        "statut" => "1"
                    );
        
        $tabAdherent = $this->adherentManager->getListeAdherentTabParams($tabParams);
        $tabAdherentTraites = array();
        foreach ($tabAdherent as $unAdherent)
        {
            $adherentTabReturn = array("CODE_ASSURE" => $unAdherent->getCodeAdherent(),
                "ASSURE_PRINCIPAL" => utf8_encode($unAdherent->getAssurePrincipal()),
                "SOUSCRIPTEUR" => utf8_encode($unAdherent->getSouscripteur()),
                "TAUX" => $unAdherent->getTaux(),
                "POLICE" => $unAdherent->getPolice(),
            );
            
            $tabAdherentTraites[] = $adherentTabReturn;
        }
        
        return $tabAdherentTraites;
    }
    
//     function genererCodeVisite()
//     {
//         return uniqid();
//     }
}
